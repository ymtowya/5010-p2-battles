import static org.junit.Assert.assertEquals;

import java.io.IOException;
import org.junit.Before;
import org.junit.Test;

/**
 * Testing the Gear.
 *
 */
public class GearTest {

  @Before
  public void setUp() throws IOException {
  }

  @Test
  public void test() {
    assertEquals(0, 0);
  }

}
