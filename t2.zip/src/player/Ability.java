package player;

/**
 * Ability is the field of players, can be affected by gears.
 *
 *
 */
public enum Ability {
  STRENGTH,
  CONSTITUITION,
  DEXTERITY,
  CHARISMA;
}
